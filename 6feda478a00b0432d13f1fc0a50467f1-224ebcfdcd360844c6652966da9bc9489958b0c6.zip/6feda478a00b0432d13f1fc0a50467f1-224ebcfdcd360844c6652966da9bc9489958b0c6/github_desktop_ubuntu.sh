## Follow this link for further updates to Github Desktop for Ubuntu https://github.com/shiftkey/desktop/releases/latest
# UPDATE (2022-11-07): Thanks to Sxvxgee's message, the updated code is as follows

sudo wget https://github.com/shiftkey/desktop/releases/download/release-3.1.1-linux1/GitHubDesktop-linux-3.1.1-linux1.deb
### Uncomment below line if you have not installed gdebi-core before
# sudo apt-get install gdebi-core 
sudo gdebi GitHubDesktop-linux-3.1.1-linux1.deb


# UPDATE (2021-10-18): Thanks to Amin Yahyaabadi's message, the updated code is as follows

#sudo wget https://github.com/shiftkey/desktop/releases/download/release-2.9.3-linux3/GitHubDesktop-linux-2.9.3-linux3.deb
### Uncomment below line if you have not installed gdebi-core before
# sudo apt-get install gdebi-core 
#sudo gdebi GitHubDesktop-linux-2.9.3-linux3.deb

# UPDATE (2021-03-05): Thanks to PaoloRanzi81's comment, the updated code is as follows https://gist.github.com/PaoloRanzi81

#sudo wget https://github.com/shiftkey/desktop/releases/download/release-2.6.3-linux1/GitHubDesktop-linux-2.6.3-linux1.deb
### Uncomment below line if you have not installed gdebi-core before
# sudo apt-get install gdebi-core 
#sudo gdebi GitHubDesktop-linux-2.6.3-linux1.deb

## Initial post
#sudo wget https://github.com/shiftkey/desktop/releases/download/release-2.1.0-linux1/GitHubDesktop-linux-2.1.0-linux1.deb
#sudo gdebi GitHubDesktop-linux-2.1.0-linux1.deb
